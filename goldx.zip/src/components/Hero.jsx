import Features from "./Features";

export default function Hero() {
  return (
    <section
      className="relative max-h-auto flex flex-col items-center justify-center px-6 pt-20 pb-[250px] w-[98%] m-auto"
      style={{
        boxShadow: "0px 1px 6px 3px #FFBF00",
      }}
    >
      {/* Content */}
      <div className="relative z-10 text-center max-w-5xl mb-20">
        <h1 className="text-6xl md:text-7xl text-[#FFBF00] font-bold mb-2 leading-tight">
          GOLDX Wallet
        </h1>

        <p className="text-xl text-[#FFBF00] md:text-2xl text-gray-300 mb-12 leading-relaxed">
          Your secure crypto wallet to explore blockchain
        </p>

        {/* <Features /> */}
        <Features />
        <button
          style={{
            background: "linear-gradient(135deg, #FFBF00 0%, #FF8000 100%)",
          }}
          className="inline-flex items-center gap-2 bg-white text-black px-8 py-3 rounded-full font-semibold hover:bg-gray-100 transition transform hover:scale-105 max-sm:mb-6"
        >
          Get started
          <span>→</span>
        </button>
      </div>
      <style>{`
        @keyframes pulse {
          0%, 100% {
            transform: scaleX(0.8) scaleY(0.6) translateZ(0px);
            opacity: 1;
          }
          50% {
            transform: scaleX(0.9) scaleY(0.7) translateZ(0px);
            opacity: 0.8;
          }
        }

        @keyframes ripple {
          0% {
            transform: scale(0.95);
            opacity: 0.8;
          }
          50% {
            transform: scale(1);
          }
          100% {
            transform: scale(0.95);
            opacity: 0.8;
          }
        }

        .gradient-glow {
          animation: pulse 4s ease-in-out infinite;
        }

        .ellipse-ripple {
          animation: ripple 3s ease-out infinite;
        }
      `}</style>

      {/* Gradient Glow - positioned below button */}
      <div
        className="absolute left-0 right-0"
        style={{
          bottom: "-10%",
          height: "70%",

          backgroundImage:
            "radial-gradient(circle at 50% 100%, rgba(255, 128, 0, 1) 5%, rgba(255, 191, 0, 0.9) 25%, rgba(255, 191, 0, 0.6) 35%, rgba(255, 191, 0, 0.3) 45%, transparent 65%)",
          transformOrigin: "50% 100%",
          opacity: 1,
          transform: "scaleX(0.8) scaleY(0.6) translateZ(0px)",
        }}
        aria-hidden="true"
      />
    </section>
  );
}
